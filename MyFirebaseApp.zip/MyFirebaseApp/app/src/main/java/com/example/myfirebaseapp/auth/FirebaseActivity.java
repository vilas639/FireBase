package com.example.myfirebaseapp.auth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.myfirebaseapp.MainActivity;
import com.example.myfirebaseapp.Notification.SimpleNotiActivity;
import com.example.myfirebaseapp.R;
import com.example.myfirebaseapp.auth.emailpassword.EmailPassActivity;
import com.example.myfirebaseapp.auth.facebooklogin.FacebookActivity;
import com.example.myfirebaseapp.auth.googlesign.GoogleActivity;
import com.example.myfirebaseapp.auth.otp.OtpActivity;

public class FirebaseActivity extends AppCompatActivity implements View.OnClickListener {

    private Button Email,Google,Facebook,OTP,Firebase,Notification1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firebase);

       Email= findViewById(R.id.email);
       Google=  findViewById(R.id.google);
       Facebook =  findViewById(R.id.facebook);
       OTP =  findViewById(R.id.otp);
       Firebase =  findViewById(R.id.firebase);
        Notification1  =  findViewById(R.id.notification);


       Email.setOnClickListener(this);
        Google.setOnClickListener(this);
        Facebook.setOnClickListener(this);
        OTP.setOnClickListener(this);
        Firebase.setOnClickListener(this);
        Notification1.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        Intent i;
        switch (v.getId())
        {
            case R.id.email:

                  i = new Intent(FirebaseActivity.this, EmailPassActivity.class);

                startActivity(i);

                break;
            case R.id.google:
                  i = new Intent(FirebaseActivity.this, GoogleActivity.class);

                startActivity(i);
                break;
            case R.id.facebook:
                  i = new Intent(FirebaseActivity.this, FacebookActivity.class);

                startActivity(i);
                break;
            case R.id.otp:
                  i = new Intent(FirebaseActivity.this, OtpActivity.class);

                startActivity(i);
                break;
            case R.id.firebase:
                  i = new Intent(FirebaseActivity.this, MainActivity.class);

                startActivity(i);
                break;

            case R.id.notification:
                i = new Intent(FirebaseActivity.this, SimpleNotiActivity.class);

                startActivity(i);
                break;
        }
    }
}
