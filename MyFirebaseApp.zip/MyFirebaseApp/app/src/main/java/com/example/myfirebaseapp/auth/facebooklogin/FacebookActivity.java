package com.example.myfirebaseapp.auth.facebooklogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myfirebaseapp.R;


import com.example.myfirebaseapp.auth.emailpassword.EmailPassActivity;
import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;

import java.util.Arrays;


public class FacebookActivity extends AppCompatActivity {

    private static final String EMAIL = "email";

   private com.facebook.login.widget.LoginButton loginButton;

    private TextView mOutputText;

    private FirebaseAuth mAuth;
    CallbackManager callbackManager;

    private String TAG;

    private FirebaseAuth.AuthStateListener mAuthStateListener;

    AccessTokenTracker accessTokenTracker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facebook);

        mOutputText = findViewById(R.id.tv_output);
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        FacebookSdk.sdkInitialize(getApplicationContext());
//        AppEventsLogger.activateApp(this);

        callbackManager = CallbackManager.Factory.create();


        loginButton = (LoginButton) findViewById(R.id.login_button);
        loginButton.setReadPermissions(Arrays.asList(EMAIL));
        // If you are using in a fragment, call loginButton.setFragment(this);






        //AccessToken accessToken = AccessToken.getCurrentAccessToken();
        //boolean isLoggedIn = accessToken != null && !accessToken.isExpired();


        LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile"));

        // Callback registration
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                // App code
                Log.d(TAG, "Onsucess"+loginResult);
                handlefacebookToken(loginResult.getAccessToken());
            }


            @Override
            public void onCancel() {
                // App code
                Log.d(TAG, "Oncancel");
            }

            @Override
            public void onError(FacebookException exception) {
                // App code

                Log.d(TAG, "OnError");
            }
        });

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                updateUI();
            }
        };

        accessTokenTracker  = new AccessTokenTracker() {
            @Override
            protected void onCurrentAccessTokenChanged(AccessToken oldAccessToken, AccessToken currentAccessToken) {
            mAuth.signOut();
            }
        };
    }



    private void handlefacebookToken(AccessToken accessToken) {

    AuthCredential credential = FacebookAuthProvider.getCredential(accessToken.getToken());

        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithEmail:success");

                            Toast.makeText(FacebookActivity.this, "Authentication Sucess.",
                                    Toast.LENGTH_SHORT).show();
                            FirebaseUser user = mAuth.getCurrentUser();
                             updateUI();
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "signInWithEmail:failure", task.getException());
                           // hideProgressBar();
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                Toast.makeText(FacebookActivity.this, "Invalid Password", Toast.LENGTH_SHORT).show();
                                mOutputText.setText("Invalid Password");
                            } else if (task.getException() instanceof FirebaseAuthInvalidUserException) {
                                Toast.makeText(FacebookActivity.this, "Email not is use", Toast.LENGTH_SHORT).show();
                                mOutputText.setText("Email not in use");
                            }
                        }

                        // ...
                    }
                });
    }






    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }


    @Override
    protected void onResume() {
        super.onResume();
        mAuth.addAuthStateListener(mAuthStateListener);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mAuthStateListener != null) {
            if (mAuth == null) {
                mAuth.removeAuthStateListener(mAuthStateListener);
            }
        }
    }

    private void updateUI()
    {
        FirebaseUser user = mAuth.getCurrentUser();

        if(user == null)
        {

            mOutputText.setText("user is not login");
            return;
        }
        else
        {
            mOutputText.setText(user.getEmail());
        }
    }
}
