package com.example.myfirebaseapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText EditName;

    private Button BtnRun;

    private TextView txtshow;

    private FirebaseDatabase mDatabase;

    private DatabaseReference mRef;

    private  ValueEventListener mListener;

    private StorageReference mStorageRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mStorageRef = FirebaseStorage.getInstance().getReference("docs/");


        EditName =  findViewById(R.id.editname);
       BtnRun =   findViewById(R.id.btnrun);

       txtshow = findViewById(R.id.txtshow);
        mDatabase = FirebaseDatabase.getInstance();
        mRef = mDatabase.getReference("Users");

        BtnRun.setOnClickListener(this);
          mListener = new ValueEventListener() {
              @Override
              public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                  String firebasevalue = dataSnapshot.getValue(String.class);
                  txtshow.setText(firebasevalue);
              }

              @Override
              public void onCancelled(@NonNull DatabaseError databaseError) {

              }
          };

          mRef.child("User1").addValueEventListener(mListener);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mRef.child("User1").removeEventListener(mListener);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId())
        {
            case R.id.btnrun:


             StorageReference child =   mStorageRef.child("office/vilas.txt");

             String data = "Vilas you are very talented";
              UploadTask  uploadTask = child.putBytes(data.getBytes());

              uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                  @Override
                  public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                      Toast.makeText(MainActivity.this,"File Uploaded",Toast.LENGTH_LONG).show();
                  }
              });





              
               
               
//                //set data to serve
//                String Editname = EditName.getText().toString();
//                mRef.child("User1").setValue(Editname).addOnSuccessListener(new OnSuccessListener<Void>() {
//                    @Override
//                    public void onSuccess(Void aVoid) {
//
//                        Toast.makeText(MainActivity.this,"data added",Toast.LENGTH_LONG).show();
//                    }
//                }).addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(@NonNull Exception e) {
//
//                        Log.e("mainActivity",e.getMessage().toString());
//                    }
//                });
//
//
//
//                mRef.child("User1").addListenerForSingleValueEvent(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                        String firebasevalue = dataSnapshot.getValue(String.class);
//                        txtshow.setText(firebasevalue);
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError databaseError) {
//
//                        Log.e("mainActivity",databaseError.getMessage().toString());
//                    }
//                });


                break;
                default:

        }
    }



    private Bitmap readImage() {

        InputStream inputStream = null;
        try {
            inputStream = getAssets().open("playstore.png");

            BitmapDrawable bitmapDrawable = (BitmapDrawable) Drawable.createFromStream(inputStream, null);

            return bitmapDrawable.getBitmap();

        } catch (IOException e) {
            e.printStackTrace();
        }
        if (inputStream != null) {
            try {
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
